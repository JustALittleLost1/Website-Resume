# Website-Resume
<!DOCTYPE html>

<html>
 <head>
	<link type="text/css" rel="stylesheet" href="stylesheet.css"/>
 </head>
 <body>
  <h1 style="font-family: Comic Sans MS">Resume of Kamryn Hues</h1>
   <div style="width:800px; height:200px; background-color:#1a53ff">
     <p style="font-family: Comic Sans MS;">A little bit about me. My name is Kamryn Hues. I'm sixteen and I'm currently employed at my father business.I really enjoy drawing and creating stuff that others as well as myself would enjoy.My passtime is sketching and playing video games. I would describe myself as a creative and determined person. I like to do things that make a differecne in peoples life. Video games are my passion and one day i would like to design the charaters in a video game.</p></div>
  <h3 style="font-family: Comic Sans MS">Work Experience</h3>	
   <div style="width:800px; height:130px; background-color:#1a53ff">
     <p style="Font-family: Comic Sans MS">This is what I have experience in so far...</p> 
        <ul>
         <li>I have been and am currently empolyed at my father car wash and detail shop.</li>
          <li>I have had odd jobs here and there but none permanet until now.</li> 
     </ul></div>
  <h3 style="font-family: Comic Sans MS">Education and Achievements</h3>
    <div style="width:800px; height:500px; background-color:#1a53ff">
     <ul>
       <h5 style="font-family: Comic Sans MS">Sports</h5>
          <li>I have been in track for five years and cross country for four years.</li>
       <h5 style="font-family: Comic Sans MS">Awards</h5>
          <li>I'm still a junior but I have got award throughout highschool.</li>
          <li>I have got numerous Young Arthur awards.</li>
          <li>I also have gone to rally for my school and my freshman year I went to state for French.</li>
       <h5 style="font-family: Comic Sans MS">Clubs</h5>
          <li>Art Club</li>
          <li>Student Council</li>
          <li>Dance Club (When we had one.)</li>
	  <li>Drama Club (When we had one...I was the DJ.)</li>
      </ul></div>

      
 </body>

</html>
